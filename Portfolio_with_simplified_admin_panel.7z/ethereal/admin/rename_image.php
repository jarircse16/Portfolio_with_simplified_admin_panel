<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rename Image</title>
</head>
<body>
    <center><h1>Rename Image</h1></center>
    <form action="rename_handler.php" method="POST">
        <label for="oldName">Select an image to rename:</label>
        <select name="oldName" id="oldName">
            <?php
            // Code to populate the dropdown list with image file names
            $imagesDir = __DIR__ . '/../Images/'; // Adjust the path to the Images directory
            $imageFiles = listImagesRecursively($imagesDir);

            foreach ($imageFiles as $imageFile) {
                $imageName = str_replace($imagesDir, '', $imageFile);
                echo '<option value="' . $imageName . '">' . $imageName . '</option>';
            }
            ?>
        </select>
        <br>
        <label for="newName">Enter the new name:</label>
        <input type="text" name="newName" id="newName" required>
        <input type="submit" value="Rename">
    </form>

    <?php
    // Include the listImagesRecursively function here
    function listImagesRecursively($dir) {
        $images = array();
        $files = scandir($dir);

        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                $filePath = $dir . '/' . $file;

                if (is_dir($filePath)) {
                    // If it's a directory, recursively list images in it
                    $images = array_merge($images, listImagesRecursively($filePath));
                } elseif (isImageFile($file)) {
                    // If it's an image file, add it to the list
                    $images[] = $filePath;
                }
            }
        }

        return $images;
    }

    function isImageFile($filename) {
        $imageExtensions = array('jpg', 'jpeg', 'png', 'gif');
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return in_array($extension, $imageExtensions);
    }
    ?>
    <center><h1><a href="index.php">Go Back</a></h1></center>
</body>
</html>
