<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Images Admin Panel</title>
    <style>
        ul {
            text-align: center;
        }
        li {
            display: inline-block;
            margin: 0 10px; /* Adjust the margin as needed */
        }
    </style>
</head>
<body>
    <center><h1>Manage Images Admin Panel</h1></center>
    <ul>
        <li><a href="view_images.php">View Images</a></li>
        <li><a href="upload_image.php">Upload Image</a></li>
        <li><a href="delete_image.php">Delete Image</a></li>
        <li><a href="rename_image.php">Rename Image</a></li>
    </ul>
</body>
</html>
