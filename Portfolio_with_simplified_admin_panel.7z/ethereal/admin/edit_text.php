<?php

session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}

// Define the path to the "texts" directory
$textsDirectory = '../texts/';

// Function to read the content of a text file
function readTextFile($directory, $fileName) {
    $filePath = $directory . $fileName;
    if (file_exists($filePath)) {
        return file_get_contents($filePath);
    } else {
        return false;
    }
}

// Function to save the content of a text file
function saveTextFile($directory, $fileName, $content) {
    $filePath = $directory . $fileName;
    return file_put_contents($filePath, $content);
}

// Get the file name from the query parameter
if (isset($_GET['file'])) {
    $fileName = $_GET['file'];
    $filePath = $textsDirectory . $fileName;

    // Handle form submission for editing and saving the text file
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $newContent = $_POST['fileContent'];
        if (saveTextFile($textsDirectory, $fileName, $newContent)) {
            echo "File '$fileName' has been saved successfully.";
        } else {
            echo "Error saving file '$fileName'.";
        }
    }

    // Read the content of the text file
    $fileContent = readTextFile($textsDirectory, $fileName);
} else {
    // If the file name is not provided, display an error
    echo "File not found.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Text File</title>
</head>
<body>
    <h1>Edit Text File: <?php echo $fileName; ?></h1>
    <form action="" method="POST">
        <textarea name="fileContent" rows="10" cols="40"><?php echo htmlspecialchars($fileContent); ?></textarea>
        <br>
        <input type="submit" value="Save">
    </form>
    <br>
    <a href="manage_texts.php">Back to File List</a>
</body>
</html>
