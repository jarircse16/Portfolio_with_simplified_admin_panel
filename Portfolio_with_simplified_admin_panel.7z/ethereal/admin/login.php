<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        .login-container {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f7f7f7;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 16px;
        }
        .form-group button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Login</h1>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
        <?php
        session_start();

        // Replace with your own username and password
        $validUsername = 'admin';
        $validPassword = 'password';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];

            // Check if the provided credentials are valid
            if ($username === $validUsername && $password === $validPassword) {
                // Set the session variable to mark the user as logged in
                $_SESSION['username'] = $username;

                // Redirect to the index page (you can replace this with the desired destination)
                header('Location: index.php');
                exit;
            } else {
                echo '<p style="color: red;">Invalid username or password. Please try again.</p>';
            }
        }
        ?>
    </div>
</body>
</html>
