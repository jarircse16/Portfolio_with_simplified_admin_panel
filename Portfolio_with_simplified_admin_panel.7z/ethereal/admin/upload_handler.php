<?php

session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadedFile = $_FILES["imageFile"]["tmp_name"];
    $originalFilename = $_FILES["imageFile"]["name"];
    $uploadDirectoryImages = __DIR__ . '/../Images/';
    $uploadDirectoryGallery = __DIR__ . '/../Images/gallery/';
    $uploadDirectoryFulls = __DIR__ . '/../Images/gallery/fulls/';
    $uploadDirectoryThumbs = __DIR__ . '/../Images/gallery/thumbs/';

    $uploadToImages = isset($_POST['uploadToImages']);
    $uploadToGallery = isset($_POST['uploadToGallery']);
    $uploadToFulls = isset($_POST['uploadToFulls']);
    $uploadToThumbs = isset($_POST['uploadToThumbs']);

    if ($uploadToImages) {
        $targetPathImages = $uploadDirectoryImages . $originalFilename;
        if (!is_dir($uploadDirectoryImages)) {
            mkdir($uploadDirectoryImages, 0777, true); // Create the directory if it doesn't exist
        }
        move_uploaded_file($uploadedFile, $targetPathImages);
    }

    if ($uploadToGallery) {
        $targetPathGallery = $uploadDirectoryGallery . $originalFilename;
        if (!is_dir($uploadDirectoryGallery)) {
            mkdir($uploadDirectoryGallery, 0777, true); // Create the directory if it doesn't exist
        }
        move_uploaded_file($uploadedFile, $targetPathGallery);
    }

    if ($uploadToFulls) {
        $targetPathFulls = $uploadDirectoryFulls . $originalFilename;
        if (!is_dir($uploadDirectoryFulls)) {
            mkdir($uploadDirectoryFulls, 0777, true); // Create the directory if it doesn't exist
        }
        move_uploaded_file($uploadedFile, $targetPathFulls);
    }

    if ($uploadToThumbs) {
        $targetPathThumbs = $uploadDirectoryThumbs . $originalFilename;
        if (!is_dir($uploadDirectoryThumbs)) {
            mkdir($uploadDirectoryThumbs, 0777, true); // Create the directory if it doesn't exist
        }
        move_uploaded_file($uploadedFile, $targetPathThumbs);
    }

    echo "The image $originalFilename has been uploaded to the selected directories.";
}
?>
