<?php
// Define constant for the root image directory
define('IMAGES_ROOT_PATH', '../images/');

// Function to recursively list image files in a directory
function listImagesRecursively($dir) {
    $images = array();
    $files = scandir($dir);

    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $filePath = $dir . '/' . $file;

            if (is_dir($filePath)) {
                // If it's a directory, recursively list images in it
                $images = array_merge($images, listImagesRecursively($filePath));
            } elseif (isImageFile($file)) {
                // If it's an image file, add it to the list
                $images[] = $filePath;
            }
        }
    }

    return $images;
}

// Function to check if a file has an image extension
function isImageFile($filename) {
    $imageExtensions = array('jpg', 'jpeg', 'png', 'gif');
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, $imageExtensions);
}

// Get a list of image files from all subdirectories
$imageFiles = listImagesRecursively(IMAGES_ROOT_PATH);
$imagesPerRow = 5;
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Images</title>
    <style>
    .image-row {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }
    .image-cell {
        flex-basis: 19%;
        margin-bottom: 10px;
    }
</style>
</head>
<body>
    <center><h1>View Images</h1></center>

    <?php
        if (!empty($imageFiles)) {
            $rowCount = ceil(count($imageFiles) / $imagesPerRow);

            for ($i = 0; $i < $rowCount; $i++) {
                echo '<div class="image-row">';

                for ($j = 0; $j < $imagesPerRow; $j++) {
                    $index = $i * $imagesPerRow + $j;
                    if ($index < count($imageFiles)) {
                        echo '<div class="image-cell">';
                        echo '<img height="100%" width="100%" src="' . $imageFiles[$index] . '" alt="' . basename($imageFiles[$index]) . '" />';
                        echo '</div>';
                    }
                }

                echo '</div>';
            }
        } else {
            echo 'No images found.';
        }
        ?>
          <center><h1><a href="index.php">Go Back</h1></a></center>
</body>
</html>
