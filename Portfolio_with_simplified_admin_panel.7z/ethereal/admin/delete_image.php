
<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Image</title>
</head>
<body>
  <center><h1>Delete Image</h1>
    <form action="delete_handler.php" method="POST">
        <label for="imageName">Select an image to delete:</label>
        <select name="imageName" id="imageName">
            <?php
            // Code to populate the dropdown list with image file names
            $imagesDir = __DIR__ . '/../Images/'; // Adjust the path to the Images directory
            $imageFiles = listImagesRecursively($imagesDir);

            foreach ($imageFiles as $imageFile) {
                $imageName = str_replace($imagesDir, '', $imageFile);
                echo '<option value="' . $imageName . '">' . $imageName . '</option>';
            }
            ?>
        </select>
        <br>
        <input type="submit" value="Delete">
    </form>

    <?php
    // Include the listImagesRecursively function here (same function as in rename_image.php)
    function listImagesRecursively($dir) {
        $images = array();
        $files = scandir($dir);

        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                $filePath = $dir . '/' . $file;

                if (is_dir($filePath)) {
                    // If it's a directory, recursively list images in it
                    $images = array_merge($images, listImagesRecursively($filePath));
                } elseif (isImageFile($file)) {
                    // If it's an image file, add it to the list
                    $images[] = $filePath;
                }
            }
        }

        return $images;
    }

    function isImageFile($filename) {
        $imageExtensions = array('jpg', 'jpeg', 'png', 'gif');
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return in_array($extension, $imageExtensions);
    }
    ?>
    <h1><a href="index.php">Go Back</h1></a></center>
</body>
</html>
