<?php

session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}
// Define the path to the "texts" directory
$textsDirectory = '../texts/';

// Function to list all text files in the directory
function listTextFiles($directory) {
    $textFiles = [];
    $files = scandir($directory);

    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
            $textFiles[] = $file;
        }
    }

    return $textFiles;
}

// Get a list of text files
$textFilesList = listTextFiles($textsDirectory);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Text Files</title>
    <style>
        /* Center-align the content */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h1>Manage Text Files</h1>

        <ul>
            <?php foreach ($textFilesList as $textFile) { ?>
                <li>
                    <?php echo $textFile; ?>
                    <a href="edit_text.php?file=<?php echo urlencode($textFile); ?>">Edit</a>
                </li>
            <?php } ?>
        </ul>
    </div>
</body>

</html>
<h1><a href="index.php">Go Back</h1></a>
