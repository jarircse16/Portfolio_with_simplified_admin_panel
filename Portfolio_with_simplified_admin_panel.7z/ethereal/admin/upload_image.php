<!DOCTYPE html>
<html>
<head>
    <title>Upload Image</title>
</head>
<body>
  <center><h1>Upload Image</h1>
    <h2>Select One Directory at a time</h2>
    <form action="upload_handler.php" method="POST" enctype="multipart/form-data">
        <label for="imageFile">Select an image to upload:</label>
        <input type="file" name="imageFile" id="imageFile" accept="image/*" required>
        <br><br>

        <p>Choose directories to upload to:</p>

        <input type="checkbox" name="uploadToImages" id="uploadToImages" value="1">
        <label for="uploadToImages">Upload to Images</label>
        <br><br>

        <input type="checkbox" name="uploadToGallery" id="uploadToGallery" value="1">
        <label for="uploadToGallery">Upload to Gallery</label>
        <br><br>

        <input type="checkbox" name="uploadToFulls" id="uploadToFulls" value="1">
        <label for="uploadToFulls">Upload to Fulls</label>
        <br><br>

        <input type="checkbox" name="uploadToThumbs" id="uploadToThumbs" value="1">
        <label for="uploadToThumbs">Upload to Thumbs</label>
        <br><br>

        <input type="submit" value="Upload">
    </form>
    <h1><a href="index.php">Go Back</h1></a></center>
</body>
</html>
