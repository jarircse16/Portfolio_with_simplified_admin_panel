<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imageName = $_POST["imageName"];
    $imagesDir = __DIR__ . '/../Images/'; // Adjust the path to the Images directory

    // Delete the image
    $imagePath = $imagesDir . $imageName;

    if (file_exists($imagePath)) {
        unlink($imagePath);

        // Delete the corresponding thumbnail if it exists
        $thumbnailDir = __DIR__ . '/../Images/Gallery/Thumbs/'; // Adjust the path to the Thumbnails directory
        $thumbnailPath = $thumbnailDir . $imageName;

        if (file_exists($thumbnailPath)) {
            unlink($thumbnailPath);
        }

        echo "The image $imageName has been deleted.";
    } else {
        echo "The selected image does not exist.";
    }
}
?>
