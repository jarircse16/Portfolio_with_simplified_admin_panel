<?php

session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: login.php');
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $oldName = $_POST["oldName"];
    $newName = $_POST["newName"];
    $imagesDir = __DIR__ . '/../Images/'; // Adjust the path to the Images directory

    // Rename the full-size image
    $oldFullPath = $imagesDir . $oldName;
    $newFullPath = $imagesDir . $newName;

    if (file_exists($oldFullPath)) {
        rename($oldFullPath, $newFullPath);

        // Rename the corresponding thumbnail if it exists
        $thumbnailDir = __DIR__ . '/../Images/Gallery/Thumbs/'; // Adjust the path to the Thumbnails directory
        $oldThumbnailPath = $thumbnailDir . $oldName;
        $newThumbnailPath = $thumbnailDir . $newName;

        if (file_exists($oldThumbnailPath)) {
            rename($oldThumbnailPath, $newThumbnailPath);
        }

        echo "The image $oldName has been renamed to $newName.";
    } else {
        echo "The selected image does not exist.";
    }
}
?>
