<?php
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

// Define the username for this user
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Images Admin Panel</title>
    <style>
        ul {
            text-align: center;
        }
        li {
            display: inline-block;
            margin: 0 10px; /* Adjust the margin as needed */
        }
    </style>
</head>
<body>
    <center><h1>Welcome, <?php echo $username; ?></h1></center>

    <ul>
        <li><a href="manage_images.php">Manage Images</a></li>
        <li><a href="manage_texts.php">Manage Texts</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
